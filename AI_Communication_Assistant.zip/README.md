# AI-Powered Communication Assistant

**Project Purpose:**  
End-to-end AI assistant that:
- Retrieves support-related emails, filters and prioritizes them,
- Extracts key information (sentiment, urgency, contact details),
- Generates empathetic, context-aware draft responses using RAG + LLM,
- Presents everything clearly in a clean dashboard,
- Aims to improve efficiency, response quality, and customer satisfaction.

---

## Architecture Overview

```plaintext
                      ┌───────────────────────────────┐
                      │  Email Providers (IMAP/Gmail) │
                      └──────────────┬────────────────┘
                                     │ OAuth2 / IMAP
                           ┌─────────▼─────────┐
                           │  Ingestion Worker │
                           │  (Python + FastAPI)│
                           └─────────┬─────────┘
                                     │ Jobs in Redis (urgent first)
                       ┌─────────────▼─────────────┐
                       │    Priority Queue (Redis) │
                       └─────────────┬─────────────┘
                                     │
                      ┌──────────────▼──────────────┐
                      │    NLP Pipeline             │
                      │ – Sentiment & Urgency       │
                      │ – Info extraction (phone, etc.) │
                      └──────────────┬──────────────┘
                                     │
                          ┌──────────▼──────────┐
                          │     RAG + LLM Draft  │
                          │ (OpenAI / sentence-transformers) │
                          └──────────┬──────────┘
                                     │
                          ┌──────────▼──────────┐
                          │ Postgres + pgvector │
                          │ + Redis (jobs)       │
                          └──────────┬──────────┘
                                     │ REST + Websocket
                         ┌───────────▼───────────┐
                         │ Next.js (Frontend UI) │
                         │ – List, Analytics, AI draft & send │
                         └────────────────────────┘
```

---

## Sample Outputs

See `/samples/` folder for generated:
- categorized_emails.csv
- responses.json
- knowledge_base.csv
- health.json
- emails.json

---

## Core Code Snippets

### backend/app/main.py
```python
@app.post('/ingest/imap')
def ingest_imap():
    # Connect IMAP and ingest messages...
    return {'ingested': count}
```

### backend/app/worker.py
```python
while True:
    eid = pop_next_job()
    e = fetch_email(eid)
    context = retrieve_context(e['subject'] + '\n' + e['body'])
    ticket = f"{PROJECT_UUID}-{uuid.uuid4().hex[:8]}"
    prompt = PROMPT_TEMPLATE.format(context=context, body=e['body'], project_uuid=PROJECT_UUID)
    resp = openai.chat_completions.create(model='gpt-4o-mini', messages=[{'role':'user','content':prompt}])
    draft = resp.choices[0].message.content
    save_response(eid, draft, ticket)
```

### frontend/app/page.tsx
```tsx
function Dashboard() {
  const { emails, stats } = useData();
  return (
    <div>
      <Chart stats={stats} />
      {emails.map(e => (
        <EmailCard key={e.id} email={e} />
      ))}
    </div>
  );
}
```
