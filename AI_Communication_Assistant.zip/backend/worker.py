import uuid, time

def pop_next_job():
    return "job-id"

def fetch_email(eid):
    return {"id": eid, "subject": "Help", "body": "I need help logging in."}

def retrieve_context(text):
    return "KB context"

def save_response(eid, draft, ticket):
    print("Saved", eid, ticket)

while True:
    eid = pop_next_job()
    e = fetch_email(eid)
    context = retrieve_context(e['subject'] + '\n' + e['body'])
    ticket = f"proj-{uuid.uuid4().hex[:8]}"
    draft = f"Response for {e['id']}"
    save_response(eid, draft, ticket)
    time.sleep(2)
