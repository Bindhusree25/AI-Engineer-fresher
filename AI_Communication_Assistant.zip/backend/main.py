from fastapi import FastAPI

app = FastAPI()

@app.post('/ingest/imap')
def ingest_imap():
    # IMAP ingestion mock
    return {"ingested": 5}
