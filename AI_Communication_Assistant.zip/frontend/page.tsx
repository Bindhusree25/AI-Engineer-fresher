export default function Dashboard() {
  const emails = [{id: "1", subject: "Help", priority: "urgent"}];
  return (
    <div>
      <h1>AI Email Dashboard</h1>
      {emails.map(e => (
        <div key={e.id}>
          <strong>{e.subject}</strong> ({e.priority})
        </div>
      ))}
    </div>
  );
}
